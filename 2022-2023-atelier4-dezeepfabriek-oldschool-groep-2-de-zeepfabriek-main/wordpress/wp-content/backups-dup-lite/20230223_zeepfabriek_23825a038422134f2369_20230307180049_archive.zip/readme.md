STAP 2
plaats in deze folder de duplicator zip en installer
STAP 3
Voer de duplicator uit
STAP 4
hernoem dupliceer wp_config.php naar wp_config.example
STAP 5
Pas de database gegevens aan in wp_config.php naar Combell
